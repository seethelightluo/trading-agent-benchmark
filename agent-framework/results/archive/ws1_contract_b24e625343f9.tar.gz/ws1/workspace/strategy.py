"""Long-only 15-asset cross-sectional reversal ensemble.
Uses only completed daily bars and rebalances every ten trading days.
"""
import json
import math
import pandas as pd
from alphacrafter.sim.utils import (get_account_dict, get_stock_daily_data,
    get_index_daily_data, rebalance_to_weights, register_hook)

ASSETS = {"000300.SH", "SPX", "HSI", "N225", "SX5E", "000688.SH", "SOX",
          "NDX", "XAU", "COPPER", "WTI", "BTC", "ETH", "US10Y", "CN10Y"}
DEFENSIVE = {"XAU", "US10Y", "CN10Y"}
CADENCE = 10
MAX_WEIGHT = 0.20
CRYPTO_CAP = 0.12
_calls = 0
_last_target = None


def _data(symbol, days=130):
    try:
        return get_stock_daily_data(symbol=symbol, days=days)
    except Exception:
        return None


def _rank(vals, assets):
    good = sorted((float(v), a) for a, v in vals.items() if v is not None and math.isfinite(float(v)))
    out = {a: .5 for a in assets}
    if len(good) > 1:
        for i, (_, a) in enumerate(good):
            out[a] = i / (len(good) - 1)
    elif good:
        out[good[0][1]] = .5
    return out


def _cap_normalize(raw, assets):
    w = {a: max(0.0, float(raw.get(a, 0.0))) for a in assets}
    for _ in range(20):
        over = sum(max(0.0, x - MAX_WEIGHT) for x in w.values())
        if over < 1e-10:
            break
        room = [a for a in assets if w[a] < MAX_WEIGHT - 1e-10]
        for a in assets:
            w[a] = min(MAX_WEIGHT, w[a])
        if not room:
            break
        add = over / len(room)
        for a in room:
            w[a] += add
    # explicit crypto risk cap, then redistribute excess
    for _ in range(10):
        excess = sum(max(0., w[a] - CRYPTO_CAP) for a in ("BTC", "ETH") if a in w)
        if excess <= 1e-10: break
        for a in ("BTC", "ETH"):
            if a in w: w[a] = min(w[a], CRYPTO_CAP)
        room = [a for a in assets if a not in ("BTC", "ETH") and w[a] < MAX_WEIGHT-1e-10]
        if not room: break
        for a in room: w[a] += excess / len(room)
    s = sum(w.values())
    return {a: w[a] / s for a in assets} if s > 0 else {a: 1/len(assets) for a in assets}


@register_hook
def strategy_hook():
    global _calls, _last_target
    _calls += 1
    account = get_account_dict()
    watch = [a for a in account.get("watch_list", []) if a in ASSETS]
    assets = [a for a in ASSETS if a in watch] or list(ASSETS)
    # Decisions are made on the first day and then every ten trading days.
    if _calls != 1 and (_calls - 1) % CADENCE != 0:
        return
    close = {}
    for a in assets:
        f = _data(a)
        if f is not None and "close" in f and len(f) >= 65:
            close[a] = pd.Series(f["close"].astype(float).values,
                                 index=pd.to_datetime(f["date"]))
    rets = {a: s.pct_change() for a, s in close.items()}
    usable = [r.rename(a) for a, r in rets.items()]
    panel = pd.concat(usable, axis=1, join="inner").dropna().tail(90) if usable else pd.DataFrame()
    if len(panel) < 25:
        target = {a: (0.10 if a in DEFENSIVE else 0.0666667) for a in assets}
        target = _cap_normalize(target, assets)
        rebalance_to_weights(target); _last_target = target; return

    five = panel.tail(5).sum()
    dispersion = panel.std(axis=1)
    market5 = float(panel.tail(5).mean(axis=1).sum())
    stressed = market5 < 0 and float(dispersion.tail(20).mean()) >= float(dispersion.median())
    # The admitted signals are short-horizon reversal; inactive conditional signals
    # are shrunk rather than replaced by an unrelated factor.
    r5 = _rank({a: -float(v) for a, v in five.items()}, assets)
    r3 = _rank({a: -float(panel.tail(3)[a].sum()) for a in panel.columns}, assets)
    # VIX is observation-only and only conditions the reversal signal.
    vf = None
    try: vf = get_index_daily_data(symbol="VIX", days=40)
    except Exception: pass
    vix_high = False
    if vf is not None and "close" in vf and len(vf) >= 20:
        vv = pd.Series(vf["close"].astype(float).values)
        vix_high = float(vv.iloc[-1]) > float(vv.tail(20).median())
    r_cond = {a: (r5[a] if stressed else .5 + .35*(r5[a]-.5)) for a in assets}
    r_vix = {a: (r5[a] if (vix_high and market5 < 0) else .5 + .25*(r5[a]-.5)) for a in assets}
    score = {a: .6139*r_cond[a] + .249*r_vix[a] + .1371*r3.get(a, .5) for a in assets}
    # inverse-volatility scaling limits reversal concentration and rewards defensive assets in risk-off.
    vols = {a: max(float(panel[a].tail(20).std())*math.sqrt(252), .10) for a in panel.columns}
    raw = {}
    for a in assets:
        tilt = .55 + .90*score.get(a, .5)
        if stressed or (market5 < 0):
            tilt *= 1.35 if a in DEFENSIVE else .78
        elif not stressed:
            tilt *= 1.10 if a in DEFENSIVE else 1.0
        raw[a] = tilt / vols.get(a, .35)
    target = _cap_normalize(raw, assets)
    # preserve exact full universe and sum-to-one contract
    if len(assets) == 15:
        rebalance_to_weights(target)
        _last_target = target
    else:
        # simulator normally supplies all 15; never create a cash sleeve.
        rebalance_to_weights(target)
        _last_target = target
