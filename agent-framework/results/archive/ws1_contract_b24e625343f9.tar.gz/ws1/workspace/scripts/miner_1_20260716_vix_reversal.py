import pandas as pd, numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
px=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index()
r=px.pct_change(); vix=pd.read_csv('../persistent/index_data/VIX.csv',parse_dates=['date']).set_index('date').close.reindex(px.index).ffill()
# one idea: reversal strengthens during volatility shock; factor only active if VIX 5d change positive or above 60d median
base=-px.pct_change(5)
regimes={'vix_rising':vix.pct_change(5)>0,'vix_high':vix>vix.rolling(60).median(),'vix_shock':vix.pct_change(5)>vix.pct_change(5).rolling(252).quantile(.7)}
for nm,rg in regimes.items():
 out=[]
 for dt in px.index:
  if not rg.get(dt,False): continue
  z=pd.concat([base.loc[dt],r.shift(-1).loc[dt]],axis=1).dropna()
  if len(z)>=8: out.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
 a=pd.Series(out).dropna(); print(nm,'dates',len(a),'IC %.5f ICIR %.5f hit %.3f'% (a.mean(),a.mean()/a.std(),(a>0).mean()))
# decay for best likely
for h in [1,3,5,10]:
 out=[]
 rg=regimes['vix_rising']
 for dt in px.index:
  if not rg.get(dt,False): continue
  z=pd.concat([base.loc[dt],px.pct_change(h).shift(-h).loc[dt]],axis=1).dropna()
  if len(z)>=8: out.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
 a=pd.Series(out).dropna();print('decay',h,len(a),a.mean(),a.mean()/a.std())
# coverage and regime frequency
print('total',len(px),'regime freq',[(k,float(x.mean())) for k,x in regimes.items()])
# halves
rg=regimes['vix_rising']; out=[]
for dt in px.index:
 if rg.get(dt,False):
  z=pd.concat([base.loc[dt],r.shift(-1).loc[dt]],axis=1).dropna()
  if len(z)>=8:out.append((dt,np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1]))
a=pd.DataFrame(out,columns=['d','ic']);print('halves',[round(x.ic.mean(),4) for _,x in a.groupby(np.arange(len(a))//max(1,len(a)//4))])
