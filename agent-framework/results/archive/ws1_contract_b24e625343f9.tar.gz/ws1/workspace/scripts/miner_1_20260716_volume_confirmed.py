import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
P={s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date') for s in U}
px=pd.concat({s:P[s].close for s in U},axis=1).sort_index(); vol=pd.concat({s:P[s].volume for s in U},axis=1).reindex(px.index)
r=px.pct_change(); rv=-r.rolling(5).sum(); vs=(vol/vol.rolling(20).median()-1).clip(-.8,3)
fac=rv*(1+vs.clip(lower=0)); market=r.mean(axis=1); dispersion=r.rolling(5).std().mean(axis=1)
cond=(market.rolling(5).sum()<0)&(dispersion>dispersion.rolling(60).median())
for name,f in [('volume_confirmed_reversal',fac),('volume_shock_reversal',rv*vs.clip(lower=0))]:
 for h in [1,3,5,10]:
  out=[]
  for d in px.index:
   if not bool(cond.get(d,False)): continue
   z=pd.concat([f.loc[d],px.pct_change(h).shift(-h).loc[d]],axis=1).dropna()
   if len(z)>=8 and z.iloc[:,0].nunique()>1: out.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
  a=pd.Series(out).dropna();print(name,h,'dates',len(a),'mean',a.mean(),'ICIR',a.mean()/a.std() if a.std() else np.nan,'hit',(a>0).mean())
print('active',cond.sum(),'rows',len(px),'assets',len(U))
