import pandas as pd, numpy as np, glob, os
from datetime import datetime
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
D={}
for s in U:
 d=pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').sort_index()
 D[s]=d.close.astype(float)
px=pd.concat(D,axis=1).sort_index()
ret=px.pct_change()
# candidate definitions (positive means expected higher return)
factors={
 'mom_20': px.pct_change(20),
 'mom_60': px.pct_change(60),
 'mom_120': px.pct_change(120),
 'rev_5': -px.pct_change(5),
 'lowvol_20': -ret.rolling(20).std(),
 'lowvol_60': -ret.rolling(60).std(),
 'trend_50_200': px.rolling(50).mean()/px.rolling(200).mean()-1,
 'breakout_60': px/px.rolling(60).max()-1,
}
# macro regime-free; evaluate all dates and halves/quarters
for name,f in factors.items():
  rows=[]; turnovers=[]
  for dt in px.index:
   if dt not in ret.index: continue
   x=f.loc[dt]; y=ret.shift(-1).loc[dt]; z=pd.concat([x,y],axis=1).dropna()
   if len(z)>=8:
    rows.append((dt,np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1]))
  a=pd.DataFrame(rows,columns=['date','ic']).set_index('date')
  ic=a.ic
  # rank signal turnover as average rank correlation change
  rr=f.rank(axis=1,pct=True); tc=rr.diff().abs().mean(axis=1).dropna().mean()
  halves=[]
  for _,g in a.groupby(np.arange(len(a))//int(max(1,len(a)/4))): halves.append(g.ic.mean())
  print(name,'dates',len(a),'meanIC %.5f ICIR %.4f hit %.3f med %.5f coverage %.3f turnover %.3f quarters'% (ic.mean(),ic.mean()/ic.std() if ic.std()>0 else 0,(ic>0).mean(),ic.median(),len(a)/len(px),tc),np.round(halves,4))
