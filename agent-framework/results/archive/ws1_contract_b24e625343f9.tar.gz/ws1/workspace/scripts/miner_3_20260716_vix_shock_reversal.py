import numpy as np, pandas as pd
from alphacrafter.sim.utils import get_index_daily_data,get_stock_daily_data
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
def fetch(s,n=5000):
 try:return get_index_daily_data(s,days=n)
 except FileNotFoundError:return get_stock_daily_data(s,days=n)
D={}
for s in U:
 x=fetch(s)
 if x is not None and len(x):
  x=x.copy();x['date']=pd.to_datetime(x['date']);D[s]=x.set_index('date')['close'].astype(float)
px=pd.DataFrame(D).sort_index();r=px.pct_change()
v=fetch('VIX');v['date']=pd.to_datetime(v.date);vix=v.set_index('date').close.astype(float).reindex(px.index).ffill()
bread=r.mean(axis=1).rolling(5).sum();vchg=vix.pct_change(5);f=-px.pct_change(5)
rows=[]
for d in px.index:
 if not (bread.loc[d]<0 and vchg.loc[d]>.08):continue
 z=pd.concat([f.loc[d],r.shift(-1).loc[d]],axis=1).dropna()
 if len(z)>=8:rows.append((d,z.iloc[:,0].corr(z.iloc[:,1]),len(z)))
a=pd.DataFrame(rows,columns=['date','ic','n']).set_index('date')
print('dates',len(px),'instruments',len(D),'active_dates',len(a),'mean_n',a.n.mean() if len(a) else 0)
if len(a):
 print('IC',a.ic.mean(),'ICIR',a.ic.mean()/a.ic.std(ddof=1),'hit',(a.ic>0).mean(),'coverage',a.n.mean()/15)
 for h in [1,3,5,10]:
  q=[];rr=px.pct_change(h).shift(-h)
  for d in a.index:
   z=pd.concat([f.loc[d],rr.loc[d]],axis=1).dropna()
   if len(z)>=8:q.append(z.iloc[:,0].corr(z.iloc[:,1]))
  print('decay',h,np.mean(q),len(q))
 print(a.assign(q=a.index.to_period('Q')).groupby('q').ic.agg(['mean','count']).tail(12).to_string())
