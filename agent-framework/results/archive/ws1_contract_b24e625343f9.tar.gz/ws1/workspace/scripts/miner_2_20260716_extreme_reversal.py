import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index().loc[:'2026-07-15']
r5=p.pct_change(5); m=r5.mean(axis=1); disp=r5.std(axis=1)
reg=(m<0)&(disp>disp.rolling(60,min_periods=30).median())
# Extreme-move reversal: reverse 5d return, weighted by cross-sectional absolute shock rank.
w=r5.abs().rank(axis=1,pct=True)
x=-r5*(0.5+0.5*w)
print('rows',len(p),'dates',p.index.min().date(),p.index.max().date(),'instruments',len(U),'active',int(reg.sum()))
for h in [1,3,5,10]:
 y=p.shift(-h)/p-1; vals=[]; ns=[]
 for d in p.index[reg]:
  z=pd.concat([x.loc[d],y.loc[d]],axis=1).replace([np.inf,-np.inf],np.nan).dropna()
  if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0: vals.append(z.iloc[:,0].corr(z.iloc[:,1]));ns.append(len(z))
 a=np.array(vals); print('h',h,'dates',len(a),'avg_n',np.mean(ns) if ns else 0,'IC %.5f ICIR %.5f hit %.4f coverage %.4f'%(np.mean(a),np.mean(a)/np.std(a),np.mean(a>0),np.mean(ns)/15 if ns else 0))
print('years',reg.groupby(reg.index.year).sum().to_dict())
