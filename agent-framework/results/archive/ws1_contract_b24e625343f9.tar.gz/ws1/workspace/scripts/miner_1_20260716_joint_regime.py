import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
px=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index(); r=px.pct_change(); base=-px.pct_change(5)
vix=pd.read_csv('../persistent/index_data/VIX.csv',parse_dates=['date']).set_index('date').close.reindex(px.index).ffill()
market=r.mean(axis=1); conds={'downtrend_vixhigh':(market.rolling(5).sum()<0)&(vix>vix.rolling(60).median()),'downtrend_vixrising':(market.rolling(5).sum()<0)&(vix.pct_change(5)>0)}
for nm,c in conds.items():
 a=[]
 for d in px.index:
  if not c.get(d,False):continue
  z=pd.concat([base.loc[d],r.shift(-1).loc[d]],axis=1).dropna()
  if len(z)>=8:a.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
 a=pd.Series(a).dropna();print(nm,len(a),a.mean(),a.mean()/a.std(),(a>0).mean())
 for h in [3,5,10]:
  q=[]
  for d in px.index:
   if not c.get(d,False):continue
   z=pd.concat([base.loc[d],px.pct_change(h).shift(-h).loc[d]],axis=1).dropna()
   if len(z)>=8:q.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
  q=pd.Series(q);print(' ',h,q.mean(),q.mean()/q.std())
