import numpy as np, pandas as pd
from alphacrafter.sim.utils import get_stock_daily_data
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
def data(a):
 try:return get_stock_daily_data(a,days=3000)
 except:return None
D={a:data(a) for a in U}; C=pd.concat([x.set_index('date').close.astype(float).rename(a) for a,x in D.items() if x is not None],axis=1).sort_index(); R=C.pct_change(); fr=R.shift(-1); f=R.rolling(20).sum()
print(C.notna().sum().to_dict(), 'rows',len(C)); print('valid rows',((f.notna().sum(axis=1)>=8)&(fr.notna().sum(axis=1)>=8)).sum())
vals=[]
for dt in f.index:
 q=pd.concat([f.loc[dt].rename('f'),fr.loc[dt].rename('r')],axis=1).dropna()
 if len(q)>=8: vals.append(q.f.corr(q.r))
print('n',len(vals),'mean',np.nanmean(vals) if vals else None)
