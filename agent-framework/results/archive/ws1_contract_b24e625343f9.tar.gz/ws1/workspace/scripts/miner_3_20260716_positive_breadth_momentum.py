import pandas as pd, numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index().loc[:'2026-07-15']
r=p.pct_change(); r5=p.pct_change(5)
# Momentum is enabled only in a confirmed positive breadth regime, using completed-day data.
reg=(r5.mean(axis=1)>0) & (r5.mean(axis=1).rolling(20,min_periods=10).mean()>0)
for look in [10,20,60]:
 x=p.pct_change(look); print('LOOK',look,'rows',len(p),'assets',len(U),'active',int(reg.sum()))
 for h in [1,3,5,10]:
  y=p.shift(-h)/p-1; a=[]; cov=[]
  for d in p.index:
   if not bool(reg.get(d,False)): continue
   z=pd.concat([x.loc[d],y.loc[d]],axis=1).replace([np.inf,-np.inf],np.nan).dropna()
   if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0:
    a.append(z.iloc[:,0].corr(z.iloc[:,1])); cov.append(len(z)/15)
  a=np.array(a)
  print('h',h,'n',len(a),'IC %.5f ICIR %.5f hit %.4f cov %.4f'%(np.nanmean(a),np.nanmean(a)/np.nanstd(a),np.mean(a>0),np.mean(cov)))
 if len(a): print('annual',pd.Series(a,index=[d for d in p.index if bool(reg.get(d,False))][-len(a):]).groupby(lambda z:z.year).mean().round(4).to_dict())
 print()
