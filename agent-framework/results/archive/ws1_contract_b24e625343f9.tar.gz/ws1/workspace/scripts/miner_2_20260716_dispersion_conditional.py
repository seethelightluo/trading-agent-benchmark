import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index().loc[:'2026-07-15']
r=p.pct_change(); r5=p.pct_change(5)
# dispersion of asset 5d returns, regime uses only current completed date
breadth=r5.mean(axis=1)<0
disp=r5.std(axis=1)
reg=breadth & (disp>disp.rolling(60,min_periods=30).median())
print('rows',len(p),'dates',p.index.min().date(),p.index.max().date(),'active',int(reg.sum()))
for h in [1,3,5,10]:
 y=p.shift(-h)/p-1; x=-r5
 a=[]; cov=[]
 for d in p.index:
  if not bool(reg.loc[d]): continue
  z=pd.concat([x.loc[d],y.loc[d]],axis=1).replace([np.inf,-np.inf],np.nan).dropna()
  if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0:
   a.append(z.iloc[:,0].corr(z.iloc[:,1]));cov.append(len(z)/15)
 a=np.array(a)
 print('h',h,'n',len(a),'IC %.5f ICIR %.5f hit %.4f cov %.4f'%(a.mean(),a.mean()/a.std(),(a>0).mean(),np.mean(cov)))
# signal turnover on all dates: rank top/bottom sign change proxy correlation changes
print('disp med positive',((disp>disp.rolling(60,min_periods=30).median())&disp.notna()).mean())
print('reg years',reg.groupby(reg.index.year).sum().to_dict())
