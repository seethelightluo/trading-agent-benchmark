import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
D={s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U}
p=pd.concat(D,axis=1).sort_index(); r=p.pct_change()
# short horizon mean reversion variants and volatility-scaled reversal
F={'rev_1':-p.pct_change(1),'rev_3':-p.pct_change(3),'rev_10':-p.pct_change(10),'rev_20':-p.pct_change(20),
 'rev5_voladj':-p.pct_change(5)/r.rolling(20).std(), 'mom20_voladj':p.pct_change(20)/r.rolling(20).std(),
 'meanrev_z20':-(p-p.rolling(20).mean())/p.rolling(20).std()}
for n,f in F.items():
 out=[]
 for dt in p.index:
  z=pd.concat([f.loc[dt],r.shift(-1).loc[dt]],axis=1).dropna()
  if len(z)>=8: out.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
 a=np.array(out); print(n,len(a), 'IC %.5f ICIR %.4f hit %.3f'% (np.nanmean(a),np.nanmean(a)/np.nanstd(a),np.mean(a>0)), 'first/last',np.mean(a[:len(a)//2]),np.mean(a[len(a)//2:]))
