import numpy as np,pandas as pd
from alphacrafter.sim.utils import get_stock_daily_data
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
def get(a):
 try:
  x=get_stock_daily_data(a,days=3000).copy(); x['date']=pd.to_datetime(x.date).dt.normalize(); return x.set_index('date').close.astype(float)
 except:return None
D={a:get(a) for a in U}
def build(kind):
 out={}
 for a,c in D.items():
  r=c.pct_change()
  if kind=='mom20': f=r.rolling(20,min_periods=15).sum()
  elif kind=='mom60': f=r.rolling(60,min_periods=40).sum()
  elif kind=='mom120': f=r.rolling(120,min_periods=80).sum()
  elif kind=='reversal5': f=-r.rolling(5,min_periods=4).sum()
  elif kind=='lowvol20': f=-r.rolling(20,min_periods=15).std()
  elif kind=='trend_quality': f=r.rolling(60,min_periods=40).mean()/r.rolling(60,min_periods=40).std()
  elif kind=='consistency60': f=r.rolling(60,min_periods=40).sum()/r.abs().rolling(60,min_periods=40).sum()
  out[a]=f
 return pd.concat(out,axis=1)
for name in ['mom20','mom60','mom120','reversal5','lowvol20','trend_quality','consistency60']:
 f=build(name); vals=[]
 for dt in f.index:
  q=pd.concat([f.loc[dt].rename('f'),pd.Series({a:D[a].pct_change().shift(-1).get(dt) for a in U}).rename('r')],axis=1).dropna()
  if len(q)>=8 and q.f.nunique()>2: vals.append(q.f.corr(q.r))
 s=pd.Series(vals).dropna(); print(name,'dates',len(s),'IC',round(s.mean(),5),'ICIR',round(s.mean()/s.std(),4),'hit',round((s>0).mean(),3))
print('range',min(x.index.min() for x in D.values()),max(x.index.max() for x in D.values()),'instruments',len(D))
