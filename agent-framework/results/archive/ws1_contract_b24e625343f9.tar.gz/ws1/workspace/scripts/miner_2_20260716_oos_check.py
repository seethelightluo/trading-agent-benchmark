import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index().loc[:'2026-07-15']
r=p.pct_change(); reg=r.mean(axis=1).rolling(5).sum()<0
fac=-p.pct_change(5); yy=r.shift(-1)
print('rows',len(p),'date',p.index.min(),p.index.max(),'reg',reg.sum())
for name,x in [('plain',fac),('volscaled',fac/r.rolling(20).std())]:
 a=[]; n=[]
 for d in p.index:
  if not reg.loc[d]:continue
  z=pd.concat([x.loc[d],yy.loc[d]],axis=1).replace([np.inf,-np.inf],np.nan).dropna()
  if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0:a.append(z.iloc[:,0].corr(z.iloc[:,1]));n.append(len(z))
 a=np.array(a);print(name,len(a),np.mean(a),np.mean(a)/np.std(a),np.mean(a>0),np.mean(n)/15)
