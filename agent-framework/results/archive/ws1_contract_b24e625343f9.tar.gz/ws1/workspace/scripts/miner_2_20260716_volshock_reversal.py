import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index().loc[:'2026-07-15']
r=p.pct_change(); r3=p.pct_change(3); vol=r.rolling(20,min_periods=15).std()*np.sqrt(20)
# One interpretable idea: normalized short-horizon shock reversal during broad stressed/dispersion regime.
x=-(r3/vol.replace(0,np.nan))
market=r3.mean(axis=1)
disp=r3.std(axis=1)
reg=(market<0)&(disp>disp.rolling(60,min_periods=30).median())
print('rows',len(p),'period',p.index.min().date(),p.index.max().date(),'instruments',len(U),'active',int(reg.sum()))
for h in [1,3,5,10]:
 y=p.shift(-h)/p-1; vals=[]; cov=[]
 for d in p.index:
  if not bool(reg.loc[d]): continue
  z=pd.concat([x.loc[d],y.loc[d]],axis=1).replace([np.inf,-np.inf],np.nan).dropna()
  if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0:
   vals.append(z.iloc[:,0].corr(z.iloc[:,1])); cov.append(len(z)/15)
 a=np.asarray(vals)
 print('h',h,'dates',len(a),'avg_n',round(np.mean(cov)*15,2) if cov else 0,'IC %.5f ICIR %.5f hit %.4f coverage %.4f'%(a.mean(),a.mean()/a.std(),(a>0).mean(),np.mean(cov)))
# signal turnover: rank quintile changes among consecutive active dates
ranks=x.rank(axis=1,pct=True); active=ranks[reg]
turn=[]
for i in range(1,len(active)):
 a,b=active.iloc[i-1],active.iloc[i]; z=pd.concat([a,b],axis=1).dropna(); turn.append((z.iloc[:,0].rank().corr(z.iloc[:,1].rank())))
print('active_rank_autocorr',np.nanmean(turn) if turn else np.nan)
print('reg_years',reg.groupby(reg.index.year).sum().to_dict())
print('coverage_all',x.notna().sum(axis=1).mean()/15)
