import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
D={s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U}
p=pd.concat(D,axis=1).sort_index(); r=p.pct_change(); m=r.mean(axis=1); y=r.shift(-1)
# conditional factors, only signal valid under regime; cross sectional ranking versions
raw={'rev1':-p.pct_change(1),'rev5':-p.pct_change(5),'rev20':-p.pct_change(20),'zrev20':-(p-p.rolling(20).mean())/p.rolling(20).std()}
conds={'all':pd.Series(1,index=p.index),'down1':(m<0).astype(float),'up1':(m>0).astype(float),'down5':(m.rolling(5).sum()<0).astype(float),'highvol':(m.rolling(20).std()>m.rolling(120).std()).astype(float)}
for rn,f in raw.items():
 for cn,c in conds.items():
  x=f.mul(c,axis=0); arr=[]
  for dt in p.index:
   z=pd.concat([x.loc[dt],y.loc[dt]],axis=1).dropna()
   if len(z)>=8: arr.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
  a=np.array(arr); print(rn+'_'+cn,len(a),f'{np.nanmean(a):.5f}',f'{np.nanmean(a)/np.nanstd(a):.4f}',f'{np.mean(a>0):.3f}')
