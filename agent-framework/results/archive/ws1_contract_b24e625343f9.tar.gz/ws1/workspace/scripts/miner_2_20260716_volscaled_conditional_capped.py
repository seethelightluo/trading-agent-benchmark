import pandas as pd, numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index().loc[:'2026-07-15']
r=p.pct_change(); breadth=r.mean(axis=1); reg=breadth.rolling(5).sum()<0
vol=r.rolling(20).std(); f=-p.pct_change(5)/vol
for label,fac in [('vol_scaled',f),('plain',-p.pct_change(5))]:
  for h in [1,3,5,10]:
    a=[]; cov=[]
    yy=p.pct_change(h).shift(-h)
    for d in p.index:
      if not bool(reg.get(d,False)): continue
      z=pd.concat([fac.loc[d],yy.loc[d]],axis=1).dropna()
      if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0:a.append(z.iloc[:,0].corr(z.iloc[:,1]));cov.append(len(z)/15)
    a=np.array(a); print(label,'h',h,'dates',len(a),'IC',np.nanmean(a),'ICIR',np.nanmean(a)/np.nanstd(a),'hit',np.mean(a>0),'cov',np.mean(cov))
