import pandas as pd, numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index()
r=p.pct_change(); breadth=r.mean(axis=1); reg=(breadth.rolling(5).sum()<0)
vol=r.rolling(20).std(); f=-p.pct_change(5)/vol
# validate one interpretable volatility-normalized conditional reversal
ics=[]; cov=[]; turnover=[]; prev=None
for d in p.index:
 if not bool(reg.get(d,False)): continue
 z=pd.concat([f.loc[d],r.shift(-1).loc[d]],axis=1).dropna()
 if len(z)<8 or z.iloc[:,0].std()==0 or z.iloc[:,1].std()==0: continue
 ics.append(z.iloc[:,0].corr(z.iloc[:,1])); cov.append(len(z)/15)
 sig=f.loc[d].rank(pct=True)
 if prev is not None: turnover.append((sig-prev).abs().mean())
 prev=sig
x=np.array(ics); print('idea=vol_scaled_5d_reversal|dates=%d|instruments=15|IC=%.5f|ICIR=%.5f|hit=%.4f|coverage=%.4f|turnover=%.4f'%(len(x),np.nanmean(x),np.nanmean(x)/np.nanstd(x),np.mean(x>0),np.mean(cov),np.mean(turnover)))
for h in [1,3,5,10]:
 a=[]; yy=p.pct_change(h).shift(-h)
 for d in p.index:
  if not bool(reg.get(d,False)): continue
  z=pd.concat([f.loc[d],yy.loc[d]],axis=1).dropna()
  if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0:a.append(z.iloc[:,0].corr(z.iloc[:,1]))
 a=np.array(a);print('decay=%d|dates=%d|IC=%.5f|ICIR=%.5f'%(h,len(a),np.nanmean(a),np.nanmean(a)/np.nanstd(a)))
# yearly regime slices
for yr in sorted(set(p.index.year)):
 a=[]
 for d in p.index[p.index.year==yr]:
  if not bool(reg.get(d,False)):continue
  z=pd.concat([f.loc[d],r.shift(-1).loc[d]],axis=1).dropna()
  if len(z)>=8 and z.iloc[:,0].std()>0:a.append(z.iloc[:,0].corr(z.iloc[:,1]))
 if a: print('year',yr,'dates',len(a),'IC',np.mean(a),'hit',np.mean(np.array(a)>0))
