import pandas as pd, numpy as np
from scipy.stats import spearmanr
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
P={s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close.astype(float) for s in U}
C=pd.DataFrame(P).sort_index().loc[:pd.Timestamp('2026-07-15')]; R=C.pct_change(); Y=C.shift(-1)/C-1
F={'lowvol20':-R.rolling(20,min_periods=10).std(),'downside20':-R.clip(upper=0).pow(2).rolling(20,min_periods=10).mean().pow(.5),'reversal5':-C.pct_change(5),'range20':-(C.rolling(20,min_periods=10).max()/C.rolling(20,min_periods=10).min()-1),'risk_adj_rev':-C.pct_change(5)/R.rolling(20,min_periods=10).std()}
for n,f in F.items():
 a=[]; tr=[]; prev=None
 for dt in C.index:
  z=pd.concat([f.loc[dt].rename('f'),Y.loc[dt].rename('r')],axis=1).dropna()
  if len(z)>=8 and z.f.nunique()>2:a.append((dt,spearmanr(z.f,z.r).statistic))
  rank=f.loc[dt].rank(pct=True)
  if prev is not None:tr.append((rank-prev).abs().mean())
  prev=rank
 q=pd.DataFrame(a,columns=['d','ic']).set_index('d').ic; recent=q[q.index>=pd.Timestamp('2025-07-15')]
 print(n,len(q),round(q.mean(),4),round(q.mean()/q.std(),3),round((q>0).mean(),3),round(np.nanmean(tr),3),round(recent.mean(),4),len(recent))
 for h in [5,10]:
  yy=C.shift(-h)/C-1; aa=[]
  for dt in C.index:
   z=pd.concat([f.loc[dt],yy.loc[dt]],axis=1).dropna()
   if len(z)>=8 and z.iloc[:,0].nunique()>2:aa.append(spearmanr(z.iloc[:,0],z.iloc[:,1]).statistic)
  print(' decay',h,round(np.nanmean(aa),4),len(aa))
