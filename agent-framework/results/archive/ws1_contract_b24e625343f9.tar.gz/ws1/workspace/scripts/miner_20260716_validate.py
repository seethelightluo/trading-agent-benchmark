import pandas as pd,numpy as np
U=['000300.SH','SPX','HSI','N225','SX5E','000688.SH','SOX','NDX','XAU','COPPER','WTI','BTC','ETH','US10Y','CN10Y']
p=pd.concat({s:pd.read_csv('../persistent/stock_data/'+s+'.csv',parse_dates=['date']).set_index('date').close for s in U},axis=1).sort_index(); r=p.pct_change(); m=r.mean(axis=1); y=r.shift(-1)
for name,f,c in [('rev5_down5',-p.pct_change(5),m.rolling(5).sum()<0),('zrev20_down5',-(p-p.rolling(20).mean())/p.rolling(20).std(),m.rolling(5).sum()<0)]:
 a=[]; cov=[]
 for dt in p.index:
  if not bool(c.get(dt,False)): continue
  z=pd.concat([f.loc[dt],y.loc[dt]],axis=1).dropna()
  if len(z)>=8 and z.iloc[:,0].std()>0 and z.iloc[:,1].std()>0:a.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1]);cov.append(len(z)/15)
 a=np.array(a);print(name,'active dates',len(a),'mean',a.mean(),'std',a.std(),'ICIR',a.mean()/a.std(),'hit',(a>0).mean(),'coverage',np.mean(cov))
 for h in [1,3,5,10]:
  yy=p.pct_change(h).shift(-h)
  q=[]
  for dt in p.index:
   if not bool(c.get(dt,False)):continue
   z=pd.concat([f.loc[dt],yy.loc[dt]],axis=1).dropna()
   if len(z)>=8 and z.iloc[:,0].std()>0:q.append(np.corrcoef(z.iloc[:,0],z.iloc[:,1])[0,1])
  q=np.array(q);print(' decay',h,q.mean(),q.mean()/q.std())
