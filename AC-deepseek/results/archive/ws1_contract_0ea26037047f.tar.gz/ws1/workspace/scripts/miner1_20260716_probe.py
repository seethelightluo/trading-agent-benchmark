"""Probe data availability and account state."""
from alphacrafter.sim.utils import get_account_dict, get_stock_daily_data, get_index_daily_data
import pandas as pd, os, json

acct = get_account_dict()
print("ACCOUNT:", json.dumps({k: acct.get(k) for k in ("total_assets", "available_cash", "net_assets")}, default=str))
wl = acct.get("watch_list") or []
print("WATCH_LIST:", wl)

print("\n--- stock_data files ---")
sd = "../persistent/stock_data"
for f in sorted(os.listdir(sd))[:40]:
    print(" ", f, os.path.getsize(os.path.join(sd, f)))

print("\n--- index_data files ---")
for f in sorted(os.listdir("../persistent/index_data")):
    print(" ", f)

print("\n--- daily data sample per watchlist symbol ---")
for s in wl:
    try:
        df = get_stock_daily_data(symbol=s, days=5)
        if df is not None:
            print(f"{s}: rows={len(df)} last_date={df['date'].iloc[-1]} close={float(df['close'].iloc[-1]):.2f}")
        else:
            print(f"{s}: None")
    except Exception as e:
        print(f"{s}: ERROR {e}")

# check date.json
with open("../persistent/date.json") as fh:
    d = json.load(fh)
print("\nDATE JSON sample:", str(d)[:500])
