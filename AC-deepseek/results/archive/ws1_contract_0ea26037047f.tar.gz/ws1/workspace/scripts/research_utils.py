"""Shared research utilities for factor mining (miner_2).
Loads data clipped to the warm-up end 2026-07-15 (no lookahead beyond current date).
"""
import os
import numpy as np
import pandas as pd

WARMUP_END = "2026-07-15"
ASSETS = ["000300.SH", "SPX", "HSI", "N225", "SX5E", "000688.SH", "SOX", "NDX",
          "XAU", "COPPER", "WTI", "BTC", "ETH", "US10Y", "CN10Y"]
MACRO = ["DXY", "USDCNY", "USDJPY", "EURUSD", "VIX"]

DATA_DIR = os.path.join("..", "persistent", "stock_data")
INDEX_DIR = os.path.join("..", "persistent", "index_data")


def load_asset(symbol, end=WARMUP_END):
    df = pd.read_csv(os.path.join(DATA_DIR, f"{symbol}.csv"))
    df["date"] = pd.to_datetime(df["date"])
    df = df[df["date"] <= pd.Timestamp(end)].reset_index(drop=True)
    return df


def load_macro(symbol, end=WARMUP_END):
    df = pd.read_csv(os.path.join(INDEX_DIR, f"{symbol}.csv"))
    df["date"] = pd.to_datetime(df["date"])
    df = df[df["date"] <= pd.Timestamp(end)].reset_index(drop=True)
    return df


def price_panel(field="close", end=WARMUP_END):
    """Wide panel of close prices for the 15 tradable assets."""
    out = {}
    for s in ASSETS:
        df = load_asset(s, end)
        out[s] = df.set_index("date")[field]
    return pd.DataFrame(out).sort_index()


def return_panel(end=WARMUP_END, field="close"):
    p = price_panel(field, end)
    return p.pct_change()


def forward_returns(end=WARMUP_END, horizons=(1, 5, 10, 20), field="close"):
    """Forward (future) returns: ret_t->t+h, NaN on the last h rows."""
    p = price_panel(field, end)
    out = {}
    for h in horizons:
        out[h] = p.shift(-h) / p - 1.0
    return out


def cross_sectional_ic(factor_df, fwd_ret, min_valid=8):
    """Daily cross-sectional Spearman IC between factor and forward return.
    factor_df / fwd_ret: DataFrame indexed by date, columns = assets.
    Returns DataFrame with columns ic, n_valid.
    """
    rows = []
    idx = factor_df.index.intersection(fwd_ret.index)
    for d in idx:
        f = factor_df.loc[d]
        r = fwd_ret.loc[d]
        pair = pd.concat([f.rename("f"), r.rename("r")], axis=1).dropna()
        if len(pair) < min_valid:
            continue
        ic = pair["f"].corr(pair["r"], method="spearman")
        rows.append((d, ic, len(pair)))
    out = pd.DataFrame(rows, columns=["date", "ic", "n_valid"]).set_index("date")
    return out


def summarize_ic(ic_df, label=""):
    """Summarize IC stats: mean |IC|, ICIR (mean/std), hit rate, n dates."""
    if len(ic_df) == 0:
        print(f"[{label}] NO VALID IC OBSERVATIONS")
        return None
    ic = ic_df["ic"].dropna()
    n = len(ic)
    mean_ic = float(ic.mean())
    std_ic = float(ic.std(ddof=1)) if n > 1 else float("nan")
    icir = mean_ic / std_ic if std_ic and std_ic > 0 else float("nan")
    hit = float((ic > 0).mean())
    abs_mean = float(ic.abs().mean())
    print(f"[{label}] n_dates={n} mean_IC={mean_ic:.4f} |mean_IC|={abs_mean:.4f} "
          f"std={std_ic:.4f} ICIR={icir:.4f} hit={hit:.3f}")
    return {"n_dates": n, "mean_ic": mean_ic, "abs_mean_ic": abs_mean,
            "std_ic": std_ic, "icir": icir, "hit": hit}


def factor_turnover(factor_df, max_rank_gap=None):
    """Average fraction of assets whose factor value sign changes between dates,
    and average rank change. factor_df: date x assets."""
    if len(factor_df) < 2:
        return float("nan"), float("nan")
    vals = factor_df.dropna(how="all")
    sign = np.sign(vals)
    sign_flip = (sign.diff().abs() / 2).mean().mean()
    ranks = vals.rank(axis=1, pct=True)
    rank_chg = ranks.diff().abs().mean().mean()
    return float(sign_flip), float(rank_chg)


def coverage(factor_df):
    return float(factor_df.notna().mean().mean())


def decay_profile(factor_df, end=WARMUP_END, horizons=(1, 5, 10, 20, 30, 40, 60)):
    """Mean absolute IC at multiple forward horizons (decay analysis)."""
    fwd = forward_returns(end, horizons)
    out = {}
    for h in horizons:
        ic_df = cross_sectional_ic(factor_df, fwd[h])
        if len(ic_df):
            out[h] = float(ic_df["ic"].abs().mean())
        else:
            out[h] = float("nan")
    return out


def admission_gate(ic_df):
    """Benchmark-wide admission gates: |mean IC| >= 0.0070 AND |ICIR| >= 0.0840."""
    if ic_df is None or len(ic_df) == 0:
        return False
    ic = ic_df["ic"].dropna()
    if len(ic) == 0:
        return False
    mean_ic = float(ic.mean())
    std_ic = float(ic.std(ddof=1)) if len(ic) > 1 else float("nan")
    icir = mean_ic / std_ic if std_ic and std_ic > 0 else float("nan")
    return abs(mean_ic) >= 0.0070 and abs(icir) >= 0.0840
