"""Shared data loading + factor validation utilities for miner_3.
Warm-up window: 2020-01-01 .. 2026-07-15 (inclusive). No future data.

Data alignment: assets trade on different calendars (BTC/ETH 7d, others weekdays,
plus exchange holidays). We build a uniform business-day panel (Mon-Fri) and
forward-fill each asset's close with a max gap of 10 business days (covers CNY /
US holidays), so every business day has a full 15-asset cross-section.
"""
import pandas as pd
import numpy as np
import glob, os

END = "2026-07-15"
START = "2020-01-01"

UNIVERSE = ["000300.SH", "SPX", "HSI", "N225", "SX5E", "000688.SH", "SOX",
            "NDX", "XAU", "COPPER", "WTI", "BTC", "ETH", "US10Y", "CN10Y"]
MACRO = ["DXY", "USDCNY", "USDJPY", "EURUSD", "VIX"]

_DATA = None


def load_all():
    """Load all tradable + macro series clipped to END. Returns dict of DataFrames indexed by date."""
    global _DATA
    if _DATA is not None:
        return _DATA
    out = {}
    for f in sorted(glob.glob("../persistent/stock_data/*.csv")):
        sym = os.path.basename(f).replace(".csv", "")
        df = pd.read_csv(f, parse_dates=["date"])
        df = df[df["date"] <= END].set_index("date").sort_index()
        out[sym] = df
    for f in sorted(glob.glob("../persistent/index_data/*.csv")):
        sym = os.path.basename(f).replace(".csv", "")
        df = pd.read_csv(f, parse_dates=["date"])
        df = df[df["date"] <= END].set_index("date").sort_index()
        out[sym] = df
    _DATA = out
    return out


def business_day_index(close_series_dict, limit=10):
    """Union business-day calendar over all assets, ffill each series (limit gap)."""
    bdays = pd.bdate_range(START, END)
    panel = {}
    for s, ser in close_series_dict.items():
        p = ser.reindex(bdays).ffill(limit=limit)
        panel[s] = p
    return pd.DataFrame(panel)


def get_panels():
    """Return (close_panel, volume_panel, macro_close) on the common business-day calendar."""
    D = load_all()
    closes = {s: D[s]["close"].astype(float) for s in UNIVERSE}
    close = business_day_index(closes)
    volume = business_day_index({s: D[s]["volume"].astype(float) for s in UNIVERSE})
    macro = business_day_index({s: D[s]["close"].astype(float) for s in MACRO})
    return D, close, volume, macro


def forward_returns(close: pd.DataFrame, horizons=(1, 5, 10, 20)):
    """Forward returns per asset: fwd_h[t] = close[t+h]/close[t] - 1 (as of t)."""
    fwd = {}
    for h in horizons:
        fwd[h] = close.shift(-h) / close - 1.0
    return fwd


def daily_ic(factor_df: pd.DataFrame, fwd_ret: pd.DataFrame, min_valid=8, method="spearman"):
    """Cross-sectional IC per date between factor values and forward returns.
    Returns Series of IC indexed by date (dates with >= min_valid valid pairs)."""
    dates, ics = [], []
    common = factor_df.index.intersection(fwd_ret.index)
    for d in common:
        x = factor_df.loc[d]
        y = fwd_ret.loc[d]
        m = x.notna() & y.notna() & np.isfinite(x) & np.isfinite(y)
        if m.sum() >= min_valid:
            r = x[m].rank().corr(y[m].rank())
            if np.isfinite(r):
                dates.append(d)
                ics.append(r)
    return pd.Series(ics, index=dates)


def ic_metrics(ic: pd.Series):
    """Summarize IC series."""
    if len(ic) == 0:
        return dict(n_dates=0, ic_mean=0.0, ic_std=0.0, icir=0.0, hit=0.0, tstat=0.0)
    m, s = float(ic.mean()), float(ic.std(ddof=1))
    icir = m / s if s > 0 else 0.0
    hit = float((ic > 0).mean())
    tstat = m / (s / np.sqrt(len(ic))) if s > 0 else 0.0
    return dict(n_dates=len(ic), ic_mean=m, ic_std=s, icir=icir, hit=hit, tstat=tstat)


def turnover(factor_df: pd.DataFrame):
    """Mean daily cross-sectional rank turnover (0..1) and value autocorr."""
    r = factor_df.rank(axis=1)
    d = r.diff().abs().mean(axis=1)
    return float(d.mean()), float(r.corrwith(r.shift(1), axis=1).mean())


def validate_factor(name, factor_df, close, horizons=(1, 5, 10, 20), min_valid=8):
    """Full validation report for one factor. factor_df: dates x assets (already clipped)."""
    fwd = forward_returns(close, horizons)
    out = {"factor": name, "coverage": float(factor_df.notna().mean().mean()),
           "n_dates": int(factor_df.notna().any(axis=1).sum()),
           "horizons": {}}
    for h in horizons:
        ic = daily_ic(factor_df, fwd[h], min_valid=min_valid)
        m = ic_metrics(ic)
        m["ic"] = m.pop("ic_mean")
        out["horizons"][f"fwd{h}d"] = m
    to, ac = turnover(factor_df)
    out["turnover_rank"] = to
    out["rank_autocorr"] = ac
    return out


def report(r):
    print(f"\n=== {r['factor']} ===")
    print(f"coverage={r['coverage']:.3f} n_dates={r['n_dates']} rank_turnover={r['turnover_rank']:.3f} rank_ac={r['rank_autocorr']:.3f}")
    for h, m in r["horizons"].items():
        print(f"  {h}: IC={m['ic']:+.4f} ICIR={m['icir']:+.3f} hit={m['hit']:.3f} n={m['n_dates']} tstat={m['tstat']:+.2f}")


def admission_gate(ic: pd.Series):
    """Benchmark-wide admission gates: |mean IC| >= 0.0070 AND |ICIR| >= 0.0840."""
    m = ic_metrics(ic)
    return abs(m["ic_mean"]) >= 0.0070 and abs(m["icir"]) >= 0.0840


def get_close_volume():
    """Alias returning (D, close, volume)."""
    D, close, volume, _macro = get_panels()
    return D, close, volume
