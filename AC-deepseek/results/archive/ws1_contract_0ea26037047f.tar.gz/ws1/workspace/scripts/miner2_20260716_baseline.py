"""miner_2 baseline: verify data panel and screen classic factor families.
Warm-up window only (<= 2026-07-15). No future data.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from research_utils import (price_panel, return_panel, forward_returns,
                            cross_sectional_ic, summarize_ic, factor_turnover,
                            coverage, decay_profile, admission_gate, ASSETS)

close = price_panel("close")
ret = close.pct_change()
logc = np.log(close)
print(f"panel dates={len(close)} ({close.index[0].date()}..{close.index[-1].date()}) assets={close.shape[1]}")
print("rows per asset with close:")
print(close.notna().sum().to_string())
print("total missing cells:", int(close.isna().sum().sum()))

def zscore(x, w=60):
    return (x - x.rolling(w, min_periods=20).mean()) / x.rolling(w, min_periods=20).std()

cands = {}
# momentum / trend
cands["mom_20d"] = close / close.shift(20) - 1
cands["mom_60d"] = close / close.shift(60) - 1
cands["trend_20_60"] = close.rolling(20).mean() / close.rolling(60).mean() - 1
cands["trend_50_200"] = close.rolling(50).mean() / close.rolling(200).mean() - 1
cands["dist_high_252"] = close / close.rolling(252).max() - 1
cands["range_pos_20"] = (close - close.rolling(20).min()) / (close.rolling(20).max() - close.rolling(20).min())
cands["mom_vol_adj_60"] = (close / close.shift(60) - 1) / ret.rolling(60).std()
# volatility
vol20 = ret.rolling(20).std(); vol60 = ret.rolling(60).std()
cands["vol_20d"] = -vol20
cands["vol_ratio_20_60"] = vol20 / vol60 - 1
cands["vol_z_60"] = -zscore(vol20, 60)
# short-term reversal
cands["rev_5d"] = -(close / close.shift(5) - 1)
cands["rev_10d"] = -(close / close.shift(10) - 1)
# volume
vol = price_panel("volume")
cands["volume_z_60"] = zscore(vol, 60)
cands["vol_vol_ratio_5_20"] = vol.rolling(5).mean() / vol.rolling(20).mean() - 1

fwd = forward_returns(horizons=(1, 5, 10, 20))
rows = []
for name, f in cands.items():
    ic1 = cross_sectional_ic(f, fwd[1])
    m1 = summarize_ic(ic1, name) if len(ic1) else None
    if m1 is None:
        continue
    ic5 = cross_sectional_ic(f, fwd[5])
    m5 = summarize_ic(ic5, name + "_5d")
    rows.append((name, m1["abs_mean_ic"], m1["icir"], m1["hit"], coverage(f),
                 m5["abs_mean_ic"], m5["icir"], admission_gate(ic1)))

print("\n=== SUMMARY sorted by |IC1|*|ICIR1| ===")
rows.sort(key=lambda r: r[1] * abs(r[2]), reverse=True)
print(f"{'factor':<20}{'|IC1|':>7}{'ICIR1':>8}{'hit1':>7}{'cov':>7}{'|IC5|':>7}{'ICIR5':>8}{'gate':>6}")
for r in rows:
    print(f"{r[0]:<20}{r[1]:>7.4f}{r[2]:>8.3f}{r[3]:>7.3f}{r[4]:>7.3f}{r[5]:>7.4f}{r[6]:>8.3f}{str(r[7]):>6}")
