"""miner_1 probe: check fundamental columns availability and macro data details."""
import pandas as pd, os, json
sd = "../persistent/stock_data"
for s in ["000300.SH", "SPX", "BTC", "CN10Y", "US10Y", "XAU"]:
    df = pd.read_csv(os.path.join(sd, f"{s}.csv"))
    df["date"] = pd.to_datetime(df["date"])
    df = df[df["date"] <= "2026-07-15"]
    nonnull = {c: int(df[c].notna().sum()) for c in ["PE", "PS", "PB", "DYR", "volume"]}
    print(s, "rows:", len(df), nonnull)
print("---macro---")
for f in sorted(os.listdir("../persistent/index_data")):
    df = pd.read_csv(f"../persistent/index_data/{f}")
    df["date"] = pd.to_datetime(df["date"])
    df = df[df["date"] <= "2026-07-15"]
    print(f, "rows:", len(df), "first:", df["date"].iloc[0].date(), "last:", df["date"].iloc[-1].date())
