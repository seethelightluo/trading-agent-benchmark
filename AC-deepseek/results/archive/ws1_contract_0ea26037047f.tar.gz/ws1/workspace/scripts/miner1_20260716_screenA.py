"""miner_1 screen A: cross-asset relative strength & trend-quality factor families.
Distinct from miner_2/3 (raw momentum, vol, reversal, beta): these are
cross-sectional-normalized and cross-asset-spillover constructs.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from miner1_harness import (price_panel, macro_panel, forward_returns,
                            cross_sectional_ic, ic_stats, coverage, turnover,
                            admission_gate, validate, ASSETS)

close = price_panel("close")
ret = close.pct_change()
logc = np.log(close)
print(f"panel: dates={len(close)} ({close.index[0].date()}..{close.index[-1].date()}) assets={close.shape[1]}")
fwd = forward_returns(close, horizons=(1, 5, 10, 20))

def z(x, w=60, minp=20):
    mu = x.rolling(w, min_periods=minp).mean()
    sd = x.rolling(w, min_periods=minp).std()
    return (x - mu) / sd

def rolling_corr(y, x, w=60):
    """Rolling correlation of each y column with a single x series."""
    out = {}
    for s in y.columns:
        df = pd.concat([y[s].rename("y"), x.rename("x")], axis=1).dropna()
        out[s] = df["y"].rolling(w, min_periods=30).corr(df["x"])
    return pd.DataFrame(out)

def rolling_beta(y, x, w=60):
    out = {}
    for s in y.columns:
        df = pd.concat([y[s].rename("y"), x.rename("x")], axis=1).dropna()
        b = (df["y"].rolling(w, min_periods=30).corr(df["x"])
             * df["y"].rolling(w, min_periods=30).std()
             / df["x"].rolling(w, min_periods=30).std())
        out[s] = b
    return pd.DataFrame(out)

cands = {}

# --- A1: cross-sectional relative momentum (z-scored vs peers) ---
rmom20 = close / close.shift(20) - 1
cands["relmom_cs_20d"] = rmom20.sub(rmom20.mean(axis=1), axis=0).div(rmom20.std(axis=1), axis=0)

# --- A2: cross-sectional relative 60d momentum ---
rmom60 = close / close.shift(60) - 1
cands["relmom_cs_60d"] = rmom60.sub(rmom60.mean(axis=1), axis=0).div(rmom60.std(axis=1), axis=0)

# --- A3: trend strength = |zscore(60d return)| / vol60 (quality of trend) ---
mom60 = close / close.shift(60) - 1
vol60 = ret.rolling(60).std()
cands["trend_strength_60"] = mom60.abs() / vol60

# --- A4: time-series momentum slope via 20d linear regression beta (log price vs time) ---
def lm_slope(series, w=20):
    x = np.arange(w)
    xm = x.mean()
    def _slope(y):
        y = np.asarray(y, dtype=float)
        if np.any(~np.isfinite(y)):
            return np.nan
        ym = y.mean()
        return float(np.sum((x - xm) * (y - ym)) / np.sum((x - xm) ** 2))
    return series.rolling(w).apply(_slope, raw=True)

slope20 = lm_slope(logc, 20)
cands["trend_slope_20d"] = slope20 * 1000

# --- A5: 12-1 momentum (skip last month) ---
cands["mom_12_1"] = close.shift(21) / close.shift(252) - 1

# --- A6: cross-asset spillover: equity index avg 10d return vs commodity/crypto beta ---
eq = close[["SPX", "NDX", "SOX", "HSI", "N225", "SX5E", "000300.SH", "000688.SH"]]
eq_ret10 = (eq / eq.shift(10) - 1).mean(axis=1)  # global equity pulse
eq_beta = rolling_beta(ret, eq_ret10)
cands["eq_pulse_beta_60"] = eq_beta

# --- A7: low-vol vs high-vol spread bet: assets negatively related to VIX changes ---
vix = macro_panel("VIX")
vix_chg = vix.pct_change().rolling(20).mean()
corr_vix = rolling_corr(ret, vix_chg)
cands["vix_beta_60"] = -corr_vix   # defensive assets score high

# --- A8: distance from 200d high (drawdown) with sign: recovery vs breakdown ---
cands["drawdown_252"] = close / close.rolling(252).max() - 1

# --- A9: cross-sectional low drawdown (closer to high better) ---
dd = close / close.rolling(126).max() - 1
cands["rel_dd_126"] = dd.sub(dd.mean(axis=1), axis=0).div(dd.std(axis=1), axis=0)

# --- A10: risk-adjusted 20d reversal (z-scored) ---
r5 = close / close.shift(5) - 1
cands["rel_rev5_cs"] = -(r5.sub(r5.mean(axis=1), axis=0).div(r5.std(axis=1), axis=0))

# --- A11: volume-confirmed momentum: 20d momentum * (volume z) ---
vol = price_panel("volume")
volz = z(vol, 60)
cands["mom_vol_confirm_20"] = rmom20 * volz

results = {}
for name, f in cands.items():
    gate = validate(name, f, fwd)
    results[name] = gate

print("\n=== ADMISSION SUMMARY (gate on 1d IC) ===")
for k, v in results.items():
    print(f"  {k:<24} gate={v}")
