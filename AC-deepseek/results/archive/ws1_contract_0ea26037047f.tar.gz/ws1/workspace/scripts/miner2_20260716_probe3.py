"""miner_2 probe: data availability and basic stats for the 15-asset universe.
Warm-up window only (<= 2026-07-15). No future data. No persistence.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from research_utils import WARMUP_END, ASSETS, MACRO, load_asset, load_macro

print(f"warmup_end={WARMUP_END}")
print(f"assets={len(ASSETS)} macro={len(MACRO)}")

for s in ASSETS:
    df = load_asset(s, WARMUP_END)
    print(f"{s:<10} rows={len(df):>5} start={df['date'].iloc[0].date()} end={df['date'].iloc[-1].date()} "
          f"cols={list(df.columns)}")
print("--- macro ---")
for s in MACRO:
    df = load_macro(s, WARMUP_END)
    print(f"{s:<8} rows={len(df):>5} start={df['date'].iloc[0].date()} end={df['date'].iloc[-1].date()}")

# Quick sanity: 1-day forward return cross-sectional IC for a simple momentum factor
from research_utils import price_panel, forward_returns, cross_sectional_ic, summarize_ic
close = price_panel("close")
print(f"\nclose panel: dates={len(close)} assets={close.shape[1]}")
print(close.notna().sum().to_string())