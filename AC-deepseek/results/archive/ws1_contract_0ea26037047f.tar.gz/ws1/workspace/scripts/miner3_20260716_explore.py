"""Broad exploration of candidate factor families for the 15-asset cross-asset universe.
Warm-up window only (<=2026-07-15). Prints IC/ICIR at 1d/5d/10d for each candidate.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from miner3_common import UNIVERSE, load_all, validate_factor, report, get_close_volume

D, close, volume = get_close_volume()
ret = close.pct_change()
logc = np.log(close)
n = len(close)
print(f"dates={n} ({close.index[0].date()}..{close.index[-1].date()}) assets={len(UNIVERSE)}")

def zscore(x, w=60):
    return (x - x.rolling(w, min_periods=20).mean()) / x.rolling(w, min_periods=20).std()

cands = {}

# ---- 1. Momentum / trend family ----
cands["mom_20d"] = close / close.shift(20) - 1
cands["mom_60d"] = close / close.shift(60) - 1
cands["mom_120d"] = close / close.shift(120) - 1
cands["mom_252d"] = close / close.shift(252) - 1
cands["trend_20_60"] = close.rolling(20).mean() / close.rolling(60).mean() - 1
cands["trend_50_200"] = close.rolling(50).mean() / close.rolling(200).mean() - 1
cands["close_vs_ma60"] = close / close.rolling(60).mean() - 1
cands["close_vs_ma200"] = close / close.rolling(200).mean() - 1
cands["dist_high_252"] = close / close.rolling(252).max() - 1          # drawdown proximity
cands["dist_low_252"] = close / close.rolling(252).min() - 1
cands["range_pos_20"] = (close - close.rolling(20).min()) / (close.rolling(20).max() - close.rolling(20).min())
cands["momentum_vol_adj"] = (close / close.shift(60) - 1) / close.pct_change().rolling(60).std()

# ---- 2. Volatility family ----
vol20 = ret.rolling(20).std()
vol60 = ret.rolling(60).std()
cands["vol_20d"] = -vol20
cands["vol_60d"] = -vol60
cands["vol_ratio_20_60"] = vol20 / vol60 - 1
cands["downside_vol_20"] = -ret.clip(upper=0).rolling(20).std()
cands["vol_zscore_60"] = -zscore(vol20, 60)
cands["range_vol_20"] = -(close.rolling(20).max() / close.rolling(20).min() - 1)
cands["garman_klass_20"] = -np.log(D["SPX"]["high"]/D["SPX"]["low"]).rolling(20).std()  # placeholder sanity

# ---- 3. Volume / liquidity family ----
cands["vol_volume_20"] = volume.rolling(20).mean() / volume.rolling(60).mean() - 1
cands["volume_zscore_20"] = zscore(volume, 60)
cands["amihud_illiq_20"] = -(ret.abs() / volume).rolling(20).mean()
cands["volume_trend_5_20"] = volume.rolling(5).mean() / volume.rolling(20).mean() - 1

# ---- 4. Mean reversion (short-term reversal) ----
cands["rev_1d"] = -ret
cands["rev_5d"] = -(close / close.shift(5) - 1)
cands["rev_10d"] = -(close / close.shift(10) - 1)

# ---- 5. Cross-asset beta / correlation family ----
mkt = ret.mean(axis=1)  # equal-weight market return
beta_60 = {}
for s in UNIVERSE:
    b = ret[s].rolling(60).cov(mkt) / mkt.rolling(60).var()
    beta_60[s] = b
cands["beta_to_mkt_60"] = pd.DataFrame(beta_60)
cands["low_beta_60"] = -pd.DataFrame(beta_60)
# idiosyncratic vol (residual from market)
resid = pd.DataFrame({s: ret[s] - beta_60[s] * mkt for s in UNIVERSE})
cands["idio_vol_20"] = -resid.rolling(20).std()

# ---- 6. Macro-regime / cross-asset factors ----
vix = D["VIX"]["close"].astype(float)
dxy = D["DXY"]["close"].astype(float)
vix_level = vix.reindex(close.index).ffill()
cands["vix_level_z"] = -zscore(pd.DataFrame({s: vix_level for s in UNIVERSE}), 120)
dxy_chg = dxy.pct_change(20).reindex(close.index).ffill()
cands["dxy_mom_20"] = pd.DataFrame({s: dxy_chg for s in UNIVERSE})
# risk-on/off: high VIX -> defensive assets
cands["vix_high_defensive"] = pd.DataFrame({s: (vix_level > vix_level.rolling(120).median()) * 1.0 for s in UNIVERSE})

# ---- 7. Yield carry family ----
us10y = D["US10Y"]["close"].astype(float)
cn10y = D["CN10Y"]["close"].astype(float)
cands["us10y_mom_20"] = pd.DataFrame({s: (us10y / us10y.shift(20) - 1) for s in UNIVERSE})
cands["cn10y_mom_20"] = pd.DataFrame({s: (cn10y / cn10y.shift(20) - 1) for s in UNIVERSE})

# ---- 8. Crypto relative / cross-asset dispersion ----
cands["btc_eth_rel"] = pd.DataFrame({s: (np.log(close["BTC"]) - np.log(close["ETH"])) for s in UNIVERSE})

# run all
results = {}
for name, f in cands.items():
    try:
        r = validate_factor(name, f, close, horizons=(1, 5, 10))
        results[name] = r
    except Exception as e:
        print(f"{name}: ERROR {e}")

# summary table sorted by |IC1| * ICIR1 signal quality
rows = []
for name, r in results.items():
    h1 = r["horizons"]["fwd1d"]
    rows.append((name, h1["ic"], h1["icir"], h1["hit"], r["coverage"], r["turnover_rank"],
                 r["horizons"]["fwd5d"]["ic"], r["horizons"]["fwd10d"]["ic"]))
rows.sort(key=lambda x: abs(x[1]) * abs(x[2]), reverse=True)
print("\n{'factor': {'IC1': ..., 'ICIR1': ..., 'hit': ..., 'cov': ..., 'turn': ..., 'IC5': ..., 'IC10': ...}}")
print(f"{'factor':<24}{'IC1':>8}{'ICIR1':>8}{'hit1':>7}{'cov':>7}{'turn':>7}{'IC5':>8}{'IC10':>8}")
for r in rows:
    print(f"{r[0]:<24}{r[1]:>8.4f}{r[2]:>8.3f}{r[3]:>7.3f}{r[4]:>7.3f}{r[5]:>7.3f}{r[6]:>8.4f}{r[7]:>8.4f}")
