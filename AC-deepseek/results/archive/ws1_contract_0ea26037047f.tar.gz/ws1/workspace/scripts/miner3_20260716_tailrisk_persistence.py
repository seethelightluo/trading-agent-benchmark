"""miner_3 exploration A: tail-risk / higher-moment and return-persistence factors.
Distinct from miner_1 (relative strength/trend quality) and miner_2 (classic
momentum/vol/reversal/volume). Warm-up window only (<=2026-07-15). No persistence.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from miner3_common import UNIVERSE, load_all, validate_factor, report, admission_gate, daily_ic, ic_metrics, get_close_volume

D, close, volume = get_close_volume()
ret = close.pct_change()
logc = np.log(close)
n = len(close)
print(f"dates={n} ({close.index[0].date()}..{close.index[-1].date()}) assets={len(UNIVERSE)}")

def roll_skew(x, w):
    return x.rolling(w, min_periods=int(w*0.6)).skew()

def roll_kurt(x, w):
    return x.rolling(w, min_periods=int(w*0.6)).kurt()

def roll_autocorr(x, w, lag=1):
    out = {}
    for s in x.columns:
        ser = x[s]
        out[s] = ser.rolling(w, min_periods=int(w*0.6)).apply(
            lambda y: pd.Series(y).autocorr(lag) if len(y) > lag+2 else np.nan, raw=False)
    return pd.DataFrame(out)

cands = {}

# ---- A1: return skewness (negative skew -> crash risk, expect negative relation) ----
cands["skew_20d"] = -roll_skew(ret, 20)
cands["skew_60d"] = -roll_skew(ret, 60)
cands["skew_120d"] = -roll_skew(ret, 120)

# ---- A2: kurtosis (fat tails -> risk premium) ----
cands["kurt_60d"] = -roll_kurt(ret, 60)

# ---- A3: lottery factor: max 1d return over window (negative) ----
cands["max_ret_20d"] = -ret.rolling(20, min_periods=12).max()
cands["max_ret_60d"] = -ret.rolling(60, min_periods=36).max()

# ---- A4: crash sensitivity: min 1d return over window ----
cands["min_ret_20d"] = -ret.rolling(20, min_periods=12).min()
cands["min_ret_60d"] = -ret.rolling(60, min_periods=36).min()

# ---- A5: downside deviation (negative) and downside/upside ratio ----
downside = ret.clip(upper=0)
upside = ret.clip(lower=0)
dd20 = downside.rolling(20, min_periods=12).std()
ud20 = upside.rolling(20, min_periods=12).std()
cands["downside_dev_20"] = -dd20
cands["downside_upside_ratio_20"] = -dd20 / ud20.replace(0, np.nan)

# ---- A6: VaR / CVaR tail risk (5% quantile of daily rets, negative) ----
cands["var95_60"] = -ret.rolling(60, min_periods=36).quantile(0.05)
cands["var95_20"] = -ret.rolling(20, min_periods=12).quantile(0.05)

# ---- A7: max drawdown over 60d (negative: more drawdown = worse) ----
cum = (1 + ret).cumprod()
running_max = cum.rolling(60, min_periods=30).max()
cands["maxdd_60d"] = (cum / running_max - 1).rolling(60, min_periods=30).min()  # negative

# ---- A8: persistence: 1-day return autocorrelation (trending vs mean-reverting) ----
cands["autocorr1_20d"] = roll_autocorr(ret, 20)
cands["autocorr1_60d"] = roll_autocorr(ret, 60)

# ---- A9: efficiency ratio: |net move| / sum |moves| over 20d (trend efficiency) ----
absret = ret.abs()
cands["efficiency_20d"] = (close / close.shift(20) - 1).abs() / absret.rolling(20, min_periods=12).sum()

# ---- A10: up-day ratio over 60d (consistency of positive drift) ----
cands["upday_ratio_60"] = (ret > 0).rolling(60, min_periods=36).mean()

# ---- A11: consecutive up-day streak (short-term persistence) ----
def streak(ser):
    s = np.sign(ser)
    out = np.zeros(len(s))
    cnt = 0
    for i in range(len(s)):
        if s.iloc[i] > 0:
            cnt += 1
        else:
            cnt = 0
        out[i] = cnt
    return pd.Series(out, index=ser.index)
cands["up_streak_5d"] = pd.DataFrame({s: streak(ret[s]) for s in UNIVERSE})

results = {}
for name, f in cands.items():
    try:
        r = validate_factor(name, f, close, horizons=(1, 5, 10))
        results[name] = r
    except Exception as e:
        print(f"{name}: ERROR {e}")

rows = []
for name, r in results.items():
    h1 = r["horizons"]["fwd1d"]
    gate = abs(h1["ic"]) >= 0.0070 and abs(h1["icir"]) >= 0.0840
    rows.append((name, h1["ic"], h1["icir"], h1["hit"], r["coverage"], r["turnover_rank"],
                 r["horizons"]["fwd5d"]["ic"], r["horizons"]["fwd10d"]["ic"], gate))
rows.sort(key=lambda x: abs(x[1]) * abs(x[2]), reverse=True)
print(f"\n{'factor':<24}{'IC1':>8}{'ICIR1':>8}{'hit1':>7}{'cov':>7}{'turn':>7}{'IC5':>8}{'IC10':>8}{'gate':>6}")
for r in rows:
    print(f"{r[0]:<24}{r[1]:>8.4f}{r[2]:>8.3f}{r[3]:>7.3f}{r[4]:>7.3f}{r[5]:>7.3f}{r[6]:>8.4f}{r[7]:>8.4f}{str(r[8]):>6}")
