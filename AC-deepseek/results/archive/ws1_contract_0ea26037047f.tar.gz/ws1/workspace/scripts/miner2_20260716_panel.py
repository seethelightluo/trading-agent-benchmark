"""miner_2: build uniform business-day panel (ffill w/ max gap) and sanity-check factor framework.
Warm-up window only (<= 2026-07-15). No future data.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from research_utils import WARMUP_END, ASSETS, MACRO, load_asset, load_macro

START = "2020-01-01"


def load_series(sym):
    return load_asset(sym, WARMUP_END).set_index("date")["close"].astype(float)


def bday_panel(series_dict, gap=10):
    bdays = pd.bdate_range(START, WARMUP_END)
    panel = {}
    for s, ser in series_dict.items():
        panel[s] = ser.reindex(bdays).ffill(limit=gap)
    return pd.DataFrame(panel).sort_index()


closes = {s: load_series(s) for s in ASSETS}
volumes = {s: load_asset(s).set_index("date")["volume"].astype(float) for s in ASSETS}
macro = {s: load_macro(s).set_index("date")["close"].astype(float) for s in MACRO}

close = business_day_index = None  # placeholder to avoid accidental use
close_df = bday_panel(closes)
volume_df = bday_panel(volumes)
macro_df = bday_panel(macro)

print(f"business-day panel: dates={len(close_df)} ({close_df.index[0].date()}..{close_df.index[-1].date()}) assets={close_df.shape[1]}")
print("rows per asset after ffill:")
print(close_df.notna().sum().to_string())
print("total missing after ffill:", int(close_df.isna().sum().sum()))

close_df.to_csv("scripts/_miner2_close.csv")
volume_df.to_csv("scripts/_miner2_volume.csv")
macro_df.to_csv("scripts/_miner2_macro.csv")
print("saved panels to scripts/_miner2_*.csv")

ret = close_df.pct_change()
print("\nannualized vol per asset (last 252d):")
print((ret.tail(252).std() * np.sqrt(252)).round(3).to_string())
print("\nmean daily ret per asset:")
print(ret.mean().round(5).to_string())