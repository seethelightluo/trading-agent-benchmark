"""Shared validation harness for miner_1 (cross-asset / macro-conditional factor families).
Business-day panel reindexed from daily CSV closes; warm-up window only (<=2026-07-15).
"""
import os
import numpy as np
import pandas as pd

WARMUP_END = "2026-07-15"
ASSETS = ["000300.SH", "SPX", "HSI", "N225", "SX5E", "000688.SH", "SOX", "NDX",
          "XAU", "COPPER", "WTI", "BTC", "ETH", "US10Y", "CN10Y"]
MACRO = ["DXY", "USDCNY", "USDJPY", "EURUSD", "VIX"]
DATA_DIR = os.path.join("..", "persistent", "stock_data")
INDEX_DIR = os.path.join("..", "persistent", "index_data")


def load_asset(symbol, end=WARMUP_END):
    df = pd.read_csv(os.path.join(DATA_DIR, f"{symbol}.csv"))
    df["date"] = pd.to_datetime(df["date"])
    df = df[df["date"] <= pd.Timestamp(end)].reset_index(drop=True)
    return df


def load_macro(symbol, end=WARMUP_END):
    df = pd.read_csv(os.path.join(INDEX_DIR, f"{symbol}.csv"))
    df["date"] = pd.to_datetime(df["date"])
    df = df[df["date"] <= pd.Timestamp(end)].reset_index(drop=True)
    return df


def business_day_panel(series_dict, limit=5):
    """Reindex each series to the union business-day calendar (ffill small gaps)."""
    bdays = pd.bdate_range(series_dict[ASSETS[0]].index.min(), series_dict[ASSETS[0]].index.max())
    out = {}
    for s, ser in series_dict.items():
        out[s] = ser.reindex(bdays).ffill(limit=limit)
    return pd.DataFrame(out).sort_index()


def price_panel(field="close", end=WARMUP_END):
    return business_day_panel({s: load_asset(s, end).set_index("date")[field] for s in ASSETS})


def macro_panel(symbol, field="close", end=WARMUP_END):
    m = load_macro(symbol, end).set_index("date")[field]
    bdays = pd.bdate_range(m.index.min(), m.index.max())
    return m.reindex(bdays).ffill(limit=5)


def forward_returns(close, horizons=(1, 5, 10, 20)):
    out = {}
    for h in horizons:
        out[h] = close.shift(-h) / close - 1.0
    return out


def cross_sectional_ic(factor_df, fwd_ret, min_valid=8):
    rows = []
    for d in factor_df.index.intersection(fwd_ret.index):
        pair = pd.concat([factor_df.loc[d].rename("f"), fwd_ret.loc[d].rename("r")], axis=1).dropna()
        if len(pair) < min_valid:
            continue
        ic = pair["f"].corr(pair["r"], method="spearman")
        rows.append((d, ic, len(pair)))
    out = pd.DataFrame(rows, columns=["date", "ic", "n_valid"]).set_index("date")
    return out


def ic_stats(ic_df):
    if ic_df is None or len(ic_df) == 0:
        return None
    ic = ic_df["ic"].dropna()
    n = len(ic)
    mean_ic = float(ic.mean())
    std_ic = float(ic.std(ddof=1)) if n > 1 else float("nan")
    icir = mean_ic / std_ic if std_ic and std_ic > 0 else float("nan")
    return {"n_dates": n, "mean_ic": mean_ic, "abs_mean_ic": abs(mean_ic),
            "std_ic": std_ic, "icir": icir, "hit": float((ic > 0).mean())}


def coverage(factor_df):
    return float(factor_df.notna().mean().mean())


def turnover(factor_df):
    vals = factor_df.dropna(how="all")
    if len(vals) < 2:
        return float("nan")
    ranks = vals.rank(axis=1, pct=True)
    return float(ranks.diff().abs().mean().mean())


def admission_gate(ic_df):
    st = ic_stats(ic_df)
    if st is None or st["n_dates"] < 50:
        return False
    return st["abs_mean_ic"] >= 0.0070 and abs(st["icir"]) >= 0.0840


def validate(name, factor_df, fwd, horizons=(1, 5, 10, 20)):
    print(f"\n===== {name} =====")
    print(f"coverage={coverage(factor_df):.3f} turnover(rank)={turnover(factor_df):.4f}")
    for h in horizons:
        ic = cross_sectional_ic(factor_df, fwd[h])
        st = ic_stats(ic)
        if st:
            print(f"  h={h:>2}: n={st['n_dates']:>4} meanIC={st['mean_ic']:+.4f} |IC|={st['abs_mean_ic']:.4f} "
                  f"ICIR={st['icir']:+.3f} hit={st['hit']:.3f}")
    g1 = admission_gate(cross_sectional_ic(factor_df, fwd[1]))
    print(f"  -> gate(1d): {g1}")
    return g1
